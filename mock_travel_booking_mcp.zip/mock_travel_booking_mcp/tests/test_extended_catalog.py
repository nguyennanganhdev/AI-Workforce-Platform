import unittest
from datetime import date, timedelta

from mock_travel_mcp.data import (
    ATTRACTION_BOOKINGS,
    ATTRACTIONS,
    BUS_TRIPS,
    FLIGHT_BOOKINGS,
    FLIGHTS,
    HOTELS,
    RESTAURANTS,
)
from mock_travel_mcp.service import (
    book_attraction_ticket,
    book_flight,
    cancel_attraction_booking,
    cancel_flight_booking,
    check_attraction_availability,
    check_flight_availability,
    get_attraction_booking,
    get_flight_booking,
    get_service_catalog,
    list_customer_bookings,
    search_attractions,
    search_flights,
)


class ExtendedCatalogTest(unittest.TestCase):
    def setUp(self) -> None:
        FLIGHT_BOOKINGS.clear()
        ATTRACTION_BOOKINGS.clear()
        self.tomorrow = (date.today() + timedelta(days=1)).isoformat()

    def test_each_business_catalog_has_50_unique_records(self) -> None:
        catalogs = (
            (HOTELS, "hotel_id"),
            (BUS_TRIPS, "trip_id"),
            (RESTAURANTS, "restaurant_id"),
            (FLIGHTS, "flight_id"),
            (ATTRACTIONS, "attraction_id"),
        )
        for records, identifier in catalogs:
            with self.subTest(identifier=identifier):
                self.assertEqual(len(records), 50)
                self.assertEqual(len({record[identifier] for record in records}), 50)

        self.assertEqual(
            get_service_catalog()["record_counts"],
            {
                "hotels": 50,
                "bus_trips": 50,
                "restaurants": 50,
                "flights": 50,
                "attractions": 50,
            },
        )

    def test_flight_search_book_get_cancel_releases_seats(self) -> None:
        search = search_flights(
            origin="Ho Chi Minh",
            destination="Da Nang",
            travel_date=self.tomorrow,
            passengers=2,
        )
        self.assertTrue(search["success"])
        self.assertGreaterEqual(search["count"], 1)
        flight_id = search["items"][0]["flight_id"]
        before = check_flight_availability(
            flight_id,
            "ECONOMY",
            self.tomorrow,
            2,
        )["available_seats"]

        created = book_flight(
            flight_id=flight_id,
            cabin_class_id="ECONOMY",
            travel_date=self.tomorrow,
            passenger_names=["Nguyễn An", "Trần Bình"],
            customer_name="Nguyễn An",
            customer_phone="0902000001",
            client_reference="flight-order-1",
        )
        booking_id = created["booking"]["booking_id"]
        self.assertTrue(created["success"])
        self.assertEqual(
            get_flight_booking(booking_id)["booking"]["status"], "confirmed"
        )
        self.assertEqual(
            check_flight_availability(
                flight_id,
                "ECONOMY",
                self.tomorrow,
                1,
            )["available_seats"],
            before - 2,
        )

        cancel_flight_booking(booking_id, "Đổi lịch")
        self.assertEqual(
            check_flight_availability(
                flight_id,
                "ECONOMY",
                self.tomorrow,
                1,
            )["available_seats"],
            before,
        )

    def test_attraction_search_book_get_cancel_and_customer_list(self) -> None:
        search = search_attractions(
            city="Ho Chi Minh",
            visit_date=self.tomorrow,
            visit_time="08:00",
            visitors=3,
            category="gia dinh",
        )
        self.assertTrue(search["success"])
        self.assertGreaterEqual(search["count"], 1)
        attraction_id = search["items"][0]["attraction_id"]
        before = check_attraction_availability(
            attraction_id,
            self.tomorrow,
            "08:00",
            2,
            1,
        )["available_capacity"]

        created = book_attraction_ticket(
            attraction_id=attraction_id,
            visit_date=self.tomorrow,
            visit_time="08:00",
            adult_tickets=2,
            child_tickets=1,
            customer_name="Lê Chi",
            customer_phone="0902000002",
            visitor_names=["Lê Chi", "Phạm Dung", "Bé An"],
            client_reference="attraction-order-1",
        )
        booking_id = created["booking"]["booking_id"]
        self.assertTrue(created["success"])
        self.assertEqual(
            get_attraction_booking(booking_id)["booking"]["status"],
            "confirmed",
        )
        self.assertEqual(
            check_attraction_availability(
                attraction_id,
                self.tomorrow,
                "08:00",
                1,
                0,
            )["available_capacity"],
            before - 3,
        )
        listed = list_customer_bookings("0902000002", booking_type="attraction")
        self.assertEqual(listed["count"], 1)

        cancel_attraction_booking(booking_id)
        self.assertEqual(
            check_attraction_availability(
                attraction_id,
                self.tomorrow,
                "08:00",
                1,
                0,
            )["available_capacity"],
            before,
        )


if __name__ == "__main__":
    unittest.main()
