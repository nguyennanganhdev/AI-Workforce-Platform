import unittest
from datetime import date, timedelta

from mock_travel_mcp.data import (
    BUS_BOOKINGS,
    HOTEL_BOOKINGS,
    RESTAURANT_BOOKINGS,
)
from mock_travel_mcp.service import (
    book_bus_trip,
    book_hotel,
    book_restaurant,
    cancel_bus_booking,
    cancel_hotel_booking,
    cancel_restaurant_booking,
    check_bus_availability,
    check_hotel_availability,
    check_restaurant_availability,
    list_customer_bookings,
    search_bus_trips,
    search_hotels,
    search_restaurants,
)


class BookingServiceTest(unittest.TestCase):
    def setUp(self) -> None:
        HOTEL_BOOKINGS.clear()
        BUS_BOOKINGS.clear()
        RESTAURANT_BOOKINGS.clear()
        self.tomorrow = (date.today() + timedelta(days=1)).isoformat()
        self.day_after = (date.today() + timedelta(days=2)).isoformat()

    def test_hotel_search_book_idempotency_and_cancel(self) -> None:
        search = search_hotels(
            city="Da Nang",
            check_in=self.tomorrow,
            check_out=self.day_after,
            guests=2,
            required_amenities=["ho boi"],
        )
        self.assertTrue(search["success"])
        self.assertEqual(search["count"], 1)
        self.assertEqual(search["items"][0]["hotel_id"], "HTL-DAD-001")

        booking = book_hotel(
            hotel_id="HTL-DAD-001",
            room_type_id="OCEAN",
            check_in=self.tomorrow,
            check_out=self.day_after,
            guests=2,
            rooms=1,
            customer_name="Nguyễn An",
            customer_phone="0901000001",
            client_reference="hotel-order-1",
        )
        replay = book_hotel(
            hotel_id="HTL-DAD-001",
            room_type_id="OCEAN",
            check_in=self.tomorrow,
            check_out=self.day_after,
            guests=2,
            rooms=1,
            customer_name="Nguyễn An",
            customer_phone="0901000001",
            client_reference="hotel-order-1",
        )
        self.assertTrue(booking["success"])
        self.assertTrue(replay["idempotent_replay"])
        self.assertEqual(
            booking["booking"]["booking_id"], replay["booking"]["booking_id"]
        )
        self.assertEqual(len(HOTEL_BOOKINGS), 1)

        after_booking = check_hotel_availability(
            "HTL-DAD-001",
            "OCEAN",
            self.tomorrow,
            self.day_after,
        )
        self.assertEqual(after_booking["available_rooms"], 5)
        cancel_hotel_booking(booking["booking"]["booking_id"], "Đổi kế hoạch")
        after_cancel = check_hotel_availability(
            "HTL-DAD-001",
            "OCEAN",
            self.tomorrow,
            self.day_after,
        )
        self.assertEqual(after_cancel["available_rooms"], 6)

    def test_bus_booking_releases_seats_after_cancel(self) -> None:
        search = search_bus_trips(
            origin="Ho Chi Minh",
            destination="Da Lat",
            travel_date=self.tomorrow,
            passengers=2,
        )
        self.assertTrue(search["success"])
        self.assertGreaterEqual(search["count"], 2)

        booking = book_bus_trip(
            trip_id="BUS-SGN-DLI-0700",
            travel_date=self.tomorrow,
            seats=2,
            customer_name="Trần Bình",
            customer_phone="0901000002",
            passenger_names=["Trần Bình", "Lê Chi"],
            client_reference="bus-order-1",
        )
        self.assertTrue(booking["success"])
        self.assertEqual(
            check_bus_availability(
                "BUS-SGN-DLI-0700",
                self.tomorrow,
                1,
            )["available_seats"],
            20,
        )
        cancel_bus_booking(booking["booking"]["booking_id"])
        self.assertEqual(
            check_bus_availability(
                "BUS-SGN-DLI-0700",
                self.tomorrow,
                1,
            )["available_seats"],
            22,
        )

    def test_restaurant_search_booking_and_customer_list(self) -> None:
        search = search_restaurants(
            city="Ho Chi Minh",
            reservation_date=self.tomorrow,
            reservation_time="18:00",
            party_size=4,
            cuisine="hai san",
        )
        self.assertTrue(search["success"])
        self.assertEqual(search["count"], 1)

        booking = book_restaurant(
            restaurant_id="RES-HCM-001",
            reservation_date=self.tomorrow,
            reservation_time="18:00",
            party_size=4,
            customer_name="Phạm Dung",
            customer_phone="0901000003",
            client_reference="restaurant-order-1",
        )
        self.assertTrue(booking["success"])
        self.assertEqual(
            check_restaurant_availability(
                "RES-HCM-001",
                self.tomorrow,
                "18:00",
                1,
            )["available_capacity"],
            36,
        )
        listed = list_customer_bookings("0901000003")
        self.assertEqual(listed["count"], 1)
        self.assertEqual(listed["items"][0]["booking_type"], "restaurant")
        cancel_restaurant_booking(booking["booking"]["booking_id"])
        self.assertEqual(
            list_customer_bookings("0901000003", include_cancelled=False)["count"],
            0,
        )

    def test_rejects_invalid_inputs(self) -> None:
        invalid_range = search_hotels(
            "Hà Nội",
            self.day_after,
            self.tomorrow,
        )
        self.assertFalse(invalid_range["success"])
        self.assertEqual(invalid_range["error"]["code"], "INVALID_DATE_RANGE")

        invalid_slot = book_restaurant(
            "RES-HAN-001",
            self.tomorrow,
            "03:00",
            2,
            "Test User",
            "0901000004",
        )
        self.assertFalse(invalid_slot["success"])
        self.assertEqual(invalid_slot["error"]["code"], "INVALID_TIME_SLOT")


if __name__ == "__main__":
    unittest.main()
