import math
import unittest

from mock_travel_mcp.calculator import (
    calculate_expression,
    calculate_percentage,
    calculate_statistics,
)


class CalculatorTest(unittest.TestCase):
    def test_calculates_expression_and_math_functions(self) -> None:
        basic = calculate_expression("(12 + 8) * 3 / 2")
        advanced = calculate_expression("sqrt(144) + sin(pi / 2) + 2 ** 3")

        self.assertEqual(basic["result"], 30)
        self.assertEqual(advanced["result"], 21)

    def test_rejects_code_and_unsafe_power(self) -> None:
        code = calculate_expression("__import__('os').getcwd()")
        power = calculate_expression("2 ** 1000")
        division = calculate_expression("10 / 0")

        self.assertFalse(code["success"])
        self.assertFalse(power["success"])
        self.assertFalse(division["success"])

    def test_calculates_percentage_modes(self) -> None:
        self.assertEqual(calculate_percentage(200, 15)["result"], 30)
        self.assertEqual(
            calculate_percentage(200, 15, operation="increase")["result"],
            230,
        )
        self.assertEqual(
            calculate_percentage(200, 15, operation="decrease")["result"],
            170,
        )

    def test_calculates_statistics(self) -> None:
        result = calculate_statistics([1, 2, 3, 4])["result"]

        self.assertEqual(result["count"], 4)
        self.assertEqual(result["sum"], 10)
        self.assertEqual(result["mean"], 2.5)
        self.assertEqual(result["median"], 2.5)
        self.assertEqual(result["range"], 3)
        self.assertTrue(
            math.isclose(result["population_standard_deviation"], 1.1180339887),
        )


if __name__ == "__main__":
    unittest.main()
