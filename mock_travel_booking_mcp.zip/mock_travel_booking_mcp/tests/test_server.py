import unittest

from starlette.testclient import TestClient

from mock_travel_mcp.server import API_KEY, app, mcp


class MCPServerTest(unittest.TestCase):
    def test_health_and_api_key_guard(self) -> None:
        with TestClient(app) as client:
            health = client.get("/health")
            unauthorized = client.post("/mcp", json={})
            authorized = client.post(
                "/mcp",
                json={},
                headers={"Authorization": f"Bearer {API_KEY}"},
            )
        self.assertEqual(health.status_code, 200)
        self.assertEqual(health.json()["tool_count"], 35)
        self.assertEqual(unauthorized.status_code, 401)
        self.assertNotEqual(authorized.status_code, 401)

    def test_all_expected_tools_are_published(self) -> None:
        tools = mcp._tool_manager.list_tools()
        names = {tool.name for tool in tools}
        self.assertEqual(
            names,
            {
                "calculate_expression",
                "calculate_percentage",
                "calculate_statistics",
                "get_service_catalog",
                "list_customer_bookings",
                "search_hotels",
                "get_hotel_details",
                "check_hotel_availability",
                "book_hotel",
                "get_hotel_booking",
                "cancel_hotel_booking",
                "search_bus_trips",
                "get_bus_trip_details",
                "check_bus_availability",
                "book_bus_trip",
                "get_bus_booking",
                "cancel_bus_booking",
                "search_restaurants",
                "get_restaurant_details",
                "check_restaurant_availability",
                "book_restaurant",
                "get_restaurant_booking",
                "cancel_restaurant_booking",
                "search_flights",
                "get_flight_details",
                "check_flight_availability",
                "book_flight",
                "get_flight_booking",
                "cancel_flight_booking",
                "search_attractions",
                "get_attraction_details",
                "check_attraction_availability",
                "book_attraction_ticket",
                "get_attraction_booking",
                "cancel_attraction_booking",
            },
        )


if __name__ == "__main__":
    unittest.main()
