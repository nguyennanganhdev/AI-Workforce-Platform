import unittest
from datetime import date, timedelta

from mock_travel_mcp.service import (
    get_service_catalog,
    search_attractions,
    search_restaurants,
)


class TimeSlotHintTest(unittest.TestCase):
    """A wrong time slot returns the valid ones, so agents stop guessing."""

    def setUp(self) -> None:
        self.day = (date.today() + timedelta(days=7)).isoformat()

    def test_catalog_lists_slots_per_city(self) -> None:
        catalog = get_service_catalog()
        self.assertIn("08:00", catalog["attraction_time_slots"]["Đà Nẵng"])
        self.assertTrue(catalog["restaurant_time_slots"]["Đà Nẵng"])

    def test_empty_attraction_search_returns_valid_slots(self) -> None:
        empty = search_attractions(city="Đà Nẵng", visit_date=self.day, visit_time="09:13")
        self.assertEqual(empty["count"], 0)
        self.assertIn("08:00", empty["available_time_slots"])
        self.assertIn("hint", empty)
        found = search_attractions(
            city="Đà Nẵng", visit_date=self.day, visit_time=empty["available_time_slots"][0],
        )
        self.assertGreater(found["count"], 0)
        self.assertNotIn("available_time_slots", found)

    def test_empty_restaurant_search_returns_valid_slots(self) -> None:
        empty = search_restaurants(city="Đà Nẵng", reservation_date=self.day, reservation_time="09:13")
        self.assertEqual(empty["count"], 0)
        self.assertTrue(empty["available_time_slots"])

    def test_unknown_city_gets_no_slot_hint(self) -> None:
        empty = search_attractions(city="Atlantis", visit_date=self.day, visit_time="08:00")
        self.assertEqual(empty["count"], 0)
        self.assertNotIn("available_time_slots", empty)


if __name__ == "__main__":
    unittest.main()
