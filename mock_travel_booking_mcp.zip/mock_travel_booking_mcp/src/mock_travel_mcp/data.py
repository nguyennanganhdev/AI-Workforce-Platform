"""Mock catalog and mutable booking arrays.

Everything in this module is deliberately in-memory so the server can be used
as a deterministic demo fixture without a database or external provider.
"""

HOTELS: list[dict] = [
    {
        "hotel_id": "HTL-HCM-001",
        "name": "Saigon Riverside Hotel",
        "city": "Hồ Chí Minh",
        "district": "Quận 1",
        "address": "12 Tôn Đức Thắng, Quận 1, TP. Hồ Chí Minh",
        "stars": 4,
        "rating": 8.7,
        "review_count": 1248,
        "amenities": ["wifi", "hồ bơi", "phòng gym", "đỗ xe", "lễ tân 24/7"],
        "check_in_time": "14:00",
        "check_out_time": "12:00",
        "cancellation_policy": "Miễn phí trước 48 giờ; sau đó tính 1 đêm.",
        "room_types": [
            {
                "room_type_id": "DELUXE",
                "name": "Deluxe City View",
                "bed": "1 giường queen",
                "max_guests": 2,
                "price_per_night": 1450000,
                "total_rooms": 5,
                "breakfast_included": True,
            },
            {
                "room_type_id": "FAMILY",
                "name": "Family Riverside",
                "bed": "2 giường queen",
                "max_guests": 4,
                "price_per_night": 2380000,
                "total_rooms": 3,
                "breakfast_included": True,
            },
        ],
    },
    {
        "hotel_id": "HTL-HCM-002",
        "name": "Chợ Lớn Boutique Stay",
        "city": "Hồ Chí Minh",
        "district": "Quận 5",
        "address": "88 Trần Hưng Đạo, Quận 5, TP. Hồ Chí Minh",
        "stars": 3,
        "rating": 8.2,
        "review_count": 532,
        "amenities": ["wifi", "đỗ xe", "giặt ủi", "lễ tân 24/7"],
        "check_in_time": "14:00",
        "check_out_time": "11:30",
        "cancellation_policy": "Miễn phí trước 24 giờ; sau đó tính 50% tổng tiền.",
        "room_types": [
            {
                "room_type_id": "STANDARD",
                "name": "Standard Double",
                "bed": "1 giường đôi",
                "max_guests": 2,
                "price_per_night": 780000,
                "total_rooms": 8,
                "breakfast_included": False,
            },
            {
                "room_type_id": "TRIPLE",
                "name": "Triple Room",
                "bed": "1 giường đôi và 1 giường đơn",
                "max_guests": 3,
                "price_per_night": 1120000,
                "total_rooms": 4,
                "breakfast_included": False,
            },
        ],
    },
    {
        "hotel_id": "HTL-DAD-001",
        "name": "Đà Nẵng Ocean Pearl",
        "city": "Đà Nẵng",
        "district": "Sơn Trà",
        "address": "120 Võ Nguyên Giáp, Sơn Trà, Đà Nẵng",
        "stars": 5,
        "rating": 9.1,
        "review_count": 2104,
        "amenities": [
            "wifi",
            "bãi biển",
            "hồ bơi",
            "spa",
            "phòng gym",
            "đưa đón sân bay",
        ],
        "check_in_time": "15:00",
        "check_out_time": "12:00",
        "cancellation_policy": "Miễn phí trước 72 giờ; sau đó tính 1 đêm.",
        "room_types": [
            {
                "room_type_id": "OCEAN",
                "name": "Ocean View King",
                "bed": "1 giường king",
                "max_guests": 2,
                "price_per_night": 2650000,
                "total_rooms": 6,
                "breakfast_included": True,
            },
            {
                "room_type_id": "SUITE",
                "name": "Ocean Family Suite",
                "bed": "1 giường king và 2 giường đơn",
                "max_guests": 4,
                "price_per_night": 4200000,
                "total_rooms": 2,
                "breakfast_included": True,
            },
        ],
    },
    {
        "hotel_id": "HTL-HAN-001",
        "name": "Hanoi Old Quarter House",
        "city": "Hà Nội",
        "district": "Hoàn Kiếm",
        "address": "36 Hàng Bạc, Hoàn Kiếm, Hà Nội",
        "stars": 4,
        "rating": 8.9,
        "review_count": 987,
        "amenities": ["wifi", "nhà hàng", "đưa đón sân bay", "lễ tân 24/7"],
        "check_in_time": "14:00",
        "check_out_time": "12:00",
        "cancellation_policy": "Miễn phí trước 48 giờ; sau đó tính 1 đêm.",
        "room_types": [
            {
                "room_type_id": "CLASSIC",
                "name": "Classic Balcony",
                "bed": "1 giường queen",
                "max_guests": 2,
                "price_per_night": 1350000,
                "total_rooms": 5,
                "breakfast_included": True,
            },
            {
                "room_type_id": "CONNECTING",
                "name": "Connecting Family",
                "bed": "2 giường queen",
                "max_guests": 4,
                "price_per_night": 2500000,
                "total_rooms": 2,
                "breakfast_included": True,
            },
        ],
    },
    {
        "hotel_id": "HTL-DLI-001",
        "name": "Đà Lạt Pine Garden",
        "city": "Đà Lạt",
        "district": "Phường 3",
        "address": "25 Triệu Việt Vương, Phường 3, Đà Lạt",
        "stars": 3,
        "rating": 8.5,
        "review_count": 641,
        "amenities": ["wifi", "vườn", "đỗ xe", "thuê xe máy", "lò sưởi"],
        "check_in_time": "14:00",
        "check_out_time": "11:00",
        "cancellation_policy": "Miễn phí trước 24 giờ; sau đó không hoàn tiền.",
        "room_types": [
            {
                "room_type_id": "GARDEN",
                "name": "Garden Double",
                "bed": "1 giường queen",
                "max_guests": 2,
                "price_per_night": 920000,
                "total_rooms": 7,
                "breakfast_included": False,
            },
            {
                "room_type_id": "BUNGALOW",
                "name": "Pine Bungalow",
                "bed": "2 giường queen",
                "max_guests": 4,
                "price_per_night": 1750000,
                "total_rooms": 3,
                "breakfast_included": True,
            },
        ],
    },
]


BUS_TRIPS: list[dict] = [
    {
        "trip_id": "BUS-SGN-DLI-0700",
        "operator": "Mây Việt Express",
        "origin": "Hồ Chí Minh",
        "destination": "Đà Lạt",
        "departure_time": "07:00",
        "arrival_time": "14:00",
        "duration_minutes": 420,
        "vehicle_type": "Limousine 22 phòng",
        "seat_type": "cabin",
        "price_per_seat": 420000,
        "total_seats": 22,
        "pickup_points": ["Bến xe Miền Đông mới", "Ngã tư Thủ Đức"],
        "dropoff_points": ["Bến xe Đà Lạt", "Chợ Đà Lạt"],
        "amenities": ["wifi", "nước uống", "chăn", "cổng sạc USB"],
        "cancellation_policy": "Miễn phí trước giờ khởi hành 24 giờ.",
    },
    {
        "trip_id": "BUS-SGN-DLI-2300",
        "operator": "Mây Việt Express",
        "origin": "Hồ Chí Minh",
        "destination": "Đà Lạt",
        "departure_time": "23:00",
        "arrival_time": "05:30",
        "duration_minutes": 390,
        "vehicle_type": "Giường nằm 34 chỗ",
        "seat_type": "sleeper",
        "price_per_seat": 320000,
        "total_seats": 34,
        "pickup_points": ["Bến xe Miền Đông mới", "Hàng Xanh"],
        "dropoff_points": ["Bến xe Đà Lạt"],
        "amenities": ["nước uống", "chăn", "máy lạnh"],
        "cancellation_policy": "Phí hủy 20% trước 12 giờ; sau đó không hoàn tiền.",
    },
    {
        "trip_id": "BUS-SGN-DAD-1800",
        "operator": "Hải Vân Premium",
        "origin": "Hồ Chí Minh",
        "destination": "Đà Nẵng",
        "departure_time": "18:00",
        "arrival_time": "10:00",
        "duration_minutes": 960,
        "vehicle_type": "Limousine 24 phòng",
        "seat_type": "cabin",
        "price_per_seat": 720000,
        "total_seats": 24,
        "pickup_points": ["Bến xe Miền Đông mới"],
        "dropoff_points": ["Bến xe Trung tâm Đà Nẵng"],
        "amenities": ["wifi", "nước uống", "chăn", "toilet", "cổng sạc USB"],
        "cancellation_policy": "Miễn phí trước giờ khởi hành 24 giờ.",
    },
    {
        "trip_id": "BUS-HAN-DAD-1700",
        "operator": "Xuyên Việt Bus",
        "origin": "Hà Nội",
        "destination": "Đà Nẵng",
        "departure_time": "17:00",
        "arrival_time": "08:30",
        "duration_minutes": 930,
        "vehicle_type": "Giường nằm 32 chỗ",
        "seat_type": "sleeper",
        "price_per_seat": 650000,
        "total_seats": 32,
        "pickup_points": ["Bến xe Nước Ngầm"],
        "dropoff_points": ["Bến xe Trung tâm Đà Nẵng"],
        "amenities": ["wifi", "nước uống", "chăn", "máy lạnh"],
        "cancellation_policy": "Phí hủy 20% trước 12 giờ; sau đó không hoàn tiền.",
    },
    {
        "trip_id": "BUS-DAD-HUE-0830",
        "operator": "Miền Trung Shuttle",
        "origin": "Đà Nẵng",
        "destination": "Huế",
        "departure_time": "08:30",
        "arrival_time": "11:30",
        "duration_minutes": 180,
        "vehicle_type": "Limousine 11 chỗ",
        "seat_type": "seat",
        "price_per_seat": 180000,
        "total_seats": 11,
        "pickup_points": ["Sân bay Đà Nẵng", "Bảo tàng Chăm"],
        "dropoff_points": ["Bến xe phía Nam Huế", "Trung tâm Huế"],
        "amenities": ["wifi", "nước uống", "cổng sạc USB"],
        "cancellation_policy": "Miễn phí trước giờ khởi hành 12 giờ.",
    },
]


RESTAURANTS: list[dict] = [
    {
        "restaurant_id": "RES-HCM-001",
        "name": "Bếp Việt Riverside",
        "city": "Hồ Chí Minh",
        "district": "Quận 1",
        "address": "2 Nguyễn Huệ, Quận 1, TP. Hồ Chí Minh",
        "cuisines": ["Việt Nam", "hải sản"],
        "rating": 4.7,
        "review_count": 856,
        "price_level": 3,
        "average_price_per_person": 550000,
        "opening_slots": ["11:00", "12:00", "13:00", "18:00", "19:00", "20:00"],
        "capacity_per_slot": 40,
        "menu_highlights": ["gỏi bưởi tôm", "cá chẽm hấp", "bò nướng lá lốt"],
        "amenities": ["phòng riêng", "đỗ xe", "ghế trẻ em", "view sông"],
        "cancellation_policy": "Miễn phí trước giờ đặt bàn 4 giờ.",
    },
    {
        "restaurant_id": "RES-HCM-002",
        "name": "Saigon Vegan Garden",
        "city": "Hồ Chí Minh",
        "district": "Quận 3",
        "address": "41 Võ Văn Tần, Quận 3, TP. Hồ Chí Minh",
        "cuisines": ["chay", "Việt Nam"],
        "rating": 4.6,
        "review_count": 443,
        "price_level": 2,
        "average_price_per_person": 280000,
        "opening_slots": ["11:00", "12:00", "13:00", "17:30", "18:30", "19:30"],
        "capacity_per_slot": 28,
        "menu_highlights": ["lẩu nấm", "cơm sen", "gỏi cuốn chay"],
        "amenities": ["đỗ xe", "ghế trẻ em", "không gian sân vườn"],
        "cancellation_policy": "Miễn phí trước giờ đặt bàn 2 giờ.",
    },
    {
        "restaurant_id": "RES-DAD-001",
        "name": "Sóng Biển Đà Nẵng",
        "city": "Đà Nẵng",
        "district": "Sơn Trà",
        "address": "18 Hoàng Sa, Sơn Trà, Đà Nẵng",
        "cuisines": ["hải sản", "Việt Nam"],
        "rating": 4.8,
        "review_count": 1320,
        "price_level": 3,
        "average_price_per_person": 650000,
        "opening_slots": [
            "11:00",
            "12:00",
            "13:00",
            "17:30",
            "18:30",
            "19:30",
            "20:30",
        ],
        "capacity_per_slot": 60,
        "menu_highlights": ["cua rang me", "mực nướng", "lẩu hải sản"],
        "amenities": ["phòng riêng", "đỗ xe", "view biển", "ghế trẻ em"],
        "cancellation_policy": "Miễn phí trước giờ đặt bàn 4 giờ.",
    },
    {
        "restaurant_id": "RES-HAN-001",
        "name": "Hanoi Heritage Dining",
        "city": "Hà Nội",
        "district": "Hoàn Kiếm",
        "address": "15 Ngô Quyền, Hoàn Kiếm, Hà Nội",
        "cuisines": ["Việt Nam", "Bắc Bộ"],
        "rating": 4.9,
        "review_count": 712,
        "price_level": 4,
        "average_price_per_person": 950000,
        "opening_slots": ["11:30", "12:30", "18:00", "19:00", "20:00"],
        "capacity_per_slot": 32,
        "menu_highlights": ["chả cá", "nem cua bể", "vịt quay mắc mật"],
        "amenities": ["phòng riêng", "sommelier", "ghế trẻ em"],
        "cancellation_policy": "Miễn phí trước giờ đặt bàn 6 giờ.",
    },
    {
        "restaurant_id": "RES-DLI-001",
        "name": "Thông & Lửa Bistro",
        "city": "Đà Lạt",
        "district": "Phường 2",
        "address": "9 Trần Phú, Phường 2, Đà Lạt",
        "cuisines": ["Âu", "nướng"],
        "rating": 4.5,
        "review_count": 389,
        "price_level": 3,
        "average_price_per_person": 480000,
        "opening_slots": ["11:30", "12:30", "17:30", "18:30", "19:30"],
        "capacity_per_slot": 24,
        "menu_highlights": ["bò áp chảo", "cá hồi nướng", "salad rau Đà Lạt"],
        "amenities": ["lò sưởi", "không gian sân vườn", "đỗ xe"],
        "cancellation_policy": "Miễn phí trước giờ đặt bàn 2 giờ.",
    },
]


_CITIES = [
    ("HCM", "Hồ Chí Minh", "Quận 1", "Sân bay Tân Sơn Nhất", "SGN"),
    ("HAN", "Hà Nội", "Hoàn Kiếm", "Sân bay Nội Bài", "HAN"),
    ("DAD", "Đà Nẵng", "Hải Châu", "Sân bay Đà Nẵng", "DAD"),
    ("DLI", "Đà Lạt", "Phường 1", "Sân bay Liên Khương", "DLI"),
    ("NTR", "Nha Trang", "Lộc Thọ", "Sân bay Cam Ranh", "CXR"),
    ("PQC", "Phú Quốc", "Dương Đông", "Sân bay Phú Quốc", "PQC"),
    ("HUI", "Huế", "Phú Hội", "Sân bay Phú Bài", "HUI"),
    ("CTH", "Cần Thơ", "Ninh Kiều", "Sân bay Cần Thơ", "VCA"),
    ("VTA", "Vũng Tàu", "Phường 2", "Sân bay Tân Sơn Nhất", "SGN"),
    ("QNH", "Quy Nhơn", "Nguyễn Văn Cừ", "Sân bay Phù Cát", "UIH"),
]

_HOTEL_NAMES = [
    "Central Heritage Hotel",
    "Lotus Grand Hotel",
    "Sunrise Boutique",
    "Green Garden Residence",
    "Horizon Family Hotel",
]
_HOTEL_AMENITIES = [
    ["wifi", "hồ bơi", "phòng gym", "đỗ xe"],
    ["wifi", "spa", "nhà hàng", "lễ tân 24/7"],
    ["wifi", "đưa đón sân bay", "giặt ủi", "đỗ xe"],
    ["wifi", "vườn", "nhà hàng", "ghế trẻ em"],
    ["wifi", "hồ bơi", "phòng gia đình", "lễ tân 24/7"],
]

# Add 45 deterministic records while preserving the five hand-written examples.
for index in range(45):
    code, city, district, _, _ = _CITIES[index % len(_CITIES)]
    variant = index % len(_HOTEL_NAMES)
    number = index + 10
    HOTELS.append(
        {
            "hotel_id": f"HTL-{code}-{number:03d}",
            "name": f"{city} {_HOTEL_NAMES[variant]} {number}",
            "city": city,
            "district": district,
            "address": f"{number * 3} Đường Trung Tâm, {district}, {city}",
            "stars": 3 + (index % 3),
            "rating": round(8.0 + (index % 16) / 10, 1),
            "review_count": 180 + index * 37,
            "amenities": _HOTEL_AMENITIES[variant],
            "check_in_time": "14:00",
            "check_out_time": "12:00",
            "cancellation_policy": "Miễn phí trước 48 giờ; sau đó tính 1 đêm.",
            "room_types": [
                {
                    "room_type_id": "STANDARD",
                    "name": "Standard City View",
                    "bed": "1 giường queen",
                    "max_guests": 2,
                    "price_per_night": 750000 + index * 35000,
                    "total_rooms": 5 + index % 6,
                    "breakfast_included": index % 2 == 0,
                },
                {
                    "room_type_id": "FAMILY",
                    "name": "Family Suite",
                    "bed": "2 giường queen",
                    "max_guests": 4,
                    "price_per_night": 1350000 + index * 50000,
                    "total_rooms": 2 + index % 4,
                    "breakfast_included": True,
                },
            ],
        },
    )


_BUS_OPERATORS = [
    "Mây Việt Express",
    "Hải Vân Premium",
    "Xuyên Việt Bus",
    "Miền Trung Shuttle",
    "Phương Nam Limousine",
]
_BUS_DEPARTURES = ["06:00", "08:30", "13:00", "18:30", "22:00"]

for index in range(45):
    origin = _CITIES[index % len(_CITIES)]
    destination = _CITIES[(index + 1 + index // 10) % len(_CITIES)]
    departure_hour, departure_minute = map(
        int,
        _BUS_DEPARTURES[index % len(_BUS_DEPARTURES)].split(":"),
    )
    duration = 180 + (index % 8) * 75
    arrival_minutes = departure_hour * 60 + departure_minute + duration
    arrival_time = f"{arrival_minutes // 60 % 24:02d}:{arrival_minutes % 60:02d}"
    BUS_TRIPS.append(
        {
            "trip_id": f"BUS-{origin[0]}-{destination[0]}-{index + 10:04d}",
            "operator": _BUS_OPERATORS[index % len(_BUS_OPERATORS)],
            "origin": origin[1],
            "destination": destination[1],
            "departure_time": _BUS_DEPARTURES[index % len(_BUS_DEPARTURES)],
            "arrival_time": arrival_time,
            "duration_minutes": duration,
            "vehicle_type": [
                "Limousine 11 chỗ",
                "Giường nằm 34 chỗ",
                "Limousine 22 phòng",
            ][index % 3],
            "seat_type": ["seat", "sleeper", "cabin"][index % 3],
            "price_per_seat": 180000 + (index % 10) * 65000,
            "total_seats": [11, 34, 22][index % 3],
            "pickup_points": [
                f"Bến xe trung tâm {origin[1]}",
                f"Văn phòng {origin[2]}",
            ],
            "dropoff_points": [
                f"Bến xe trung tâm {destination[1]}",
                f"Trung tâm {destination[1]}",
            ],
            "amenities": ["wifi", "nước uống", "máy lạnh", "cổng sạc USB"],
            "cancellation_policy": "Miễn phí trước giờ khởi hành 24 giờ.",
        },
    )


_RESTAURANT_NAMES = [
    "Bếp Nhà",
    "Hải Sản Biển Xanh",
    "Vườn Chay An Nhiên",
    "Phố Nướng",
    "Heritage Dining",
]
_CUISINES = [
    ["Việt Nam", "đặc sản địa phương"],
    ["hải sản", "Việt Nam"],
    ["chay", "Việt Nam"],
    ["nướng", "Á"],
    ["Việt Nam", "fine dining"],
]

for index in range(45):
    code, city, district, _, _ = _CITIES[index % len(_CITIES)]
    variant = index % len(_RESTAURANT_NAMES)
    number = index + 10
    RESTAURANTS.append(
        {
            "restaurant_id": f"RES-{code}-{number:03d}",
            "name": f"{_RESTAURANT_NAMES[variant]} {city} {number}",
            "city": city,
            "district": district,
            "address": f"{number * 4} Đường Ẩm Thực, {district}, {city}",
            "cuisines": _CUISINES[variant],
            "rating": round(4.0 + (index % 10) / 10, 1),
            "review_count": 95 + index * 29,
            "price_level": 1 + index % 4,
            "average_price_per_person": 160000 + (index % 10) * 85000,
            "opening_slots": [
                "11:00",
                "12:00",
                "13:00",
                "17:30",
                "18:30",
                "19:30",
                "20:30",
            ],
            "capacity_per_slot": 24 + (index % 6) * 8,
            "menu_highlights": [
                f"món đặc sản {city}",
                "món theo mùa",
                "tráng miệng nhà làm",
            ],
            "amenities": ["đỗ xe", "ghế trẻ em", "phòng riêng"],
            "cancellation_policy": "Miễn phí trước giờ đặt bàn 4 giờ.",
        },
    )


_AIRLINES = [
    ("Vietnam Airlines", "VN"),
    ("Vietjet Air", "VJ"),
    ("Bamboo Airways", "QH"),
    ("Vietravel Airlines", "VU"),
    ("Pacific Airlines", "BL"),
]
_FLIGHT_DEPARTURES = ["06:10", "08:45", "12:20", "16:30", "20:15"]

FLIGHTS: list[dict] = []
for index in range(50):
    origin = _CITIES[index % len(_CITIES)]
    destination = _CITIES[(index + 2 + index // 10) % len(_CITIES)]
    airline, airline_code = _AIRLINES[index % len(_AIRLINES)]
    departure_hour, departure_minute = map(
        int,
        _FLIGHT_DEPARTURES[index % len(_FLIGHT_DEPARTURES)].split(":"),
    )
    duration = 55 + (index % 5) * 20
    arrival_minutes = departure_hour * 60 + departure_minute + duration
    FLIGHTS.append(
        {
            "flight_id": f"FLT-{airline_code}-{index + 101:04d}",
            "airline": airline,
            "flight_number": f"{airline_code}{index + 101}",
            "origin": origin[1],
            "destination": destination[1],
            "origin_airport": origin[3],
            "origin_airport_code": origin[4],
            "destination_airport": destination[3],
            "destination_airport_code": destination[4],
            "departure_time": _FLIGHT_DEPARTURES[index % len(_FLIGHT_DEPARTURES)],
            "arrival_time": (
                f"{arrival_minutes // 60 % 24:02d}:{arrival_minutes % 60:02d}"
            ),
            "duration_minutes": duration,
            "aircraft": ["Airbus A321", "Airbus A320", "Boeing 787-9"][index % 3],
            "cabin_classes": [
                {
                    "cabin_class_id": "ECONOMY",
                    "name": "Phổ thông",
                    "price_per_passenger": 890000 + (index % 10) * 115000,
                    "total_seats": 120 + (index % 4) * 20,
                    "cabin_baggage_kg": 7,
                    "checked_baggage_kg": 20,
                    "refundable": False,
                },
                {
                    "cabin_class_id": "BUSINESS",
                    "name": "Thương gia",
                    "price_per_passenger": 2850000 + (index % 10) * 220000,
                    "total_seats": 12 + (index % 3) * 4,
                    "cabin_baggage_kg": 14,
                    "checked_baggage_kg": 32,
                    "refundable": True,
                },
            ],
            "cancellation_policy": (
                "Hạng phổ thông không hoàn; hạng thương gia hoàn miễn phí trước 24 giờ."
            ),
        },
    )


_ATTRACTION_NAMES = [
    "Công viên Khám Phá",
    "Bảo tàng Di Sản",
    "Khu vui chơi Adventure Land",
    "Vườn sinh thái Xanh",
    "Du thuyền Hoàng Hôn",
]
_ATTRACTION_CATEGORIES = [
    ["công viên", "gia đình"],
    ["bảo tàng", "văn hóa"],
    ["vui chơi", "mạo hiểm"],
    ["sinh thái", "ngoài trời"],
    ["tham quan", "du thuyền"],
]

ATTRACTIONS: list[dict] = []
for index in range(50):
    code, city, district, _, _ = _CITIES[index % len(_CITIES)]
    variant = index % len(_ATTRACTION_NAMES)
    number = index + 1
    ATTRACTIONS.append(
        {
            "attraction_id": f"ATT-{code}-{number:03d}",
            "name": f"{_ATTRACTION_NAMES[variant]} {city} {number}",
            "city": city,
            "district": district,
            "address": f"{number * 5} Đường Du Lịch, {district}, {city}",
            "categories": _ATTRACTION_CATEGORIES[variant],
            "description": (
                f"Địa điểm trải nghiệm giả lập số {number} tại {city}, phù hợp cho "
                "khách cá nhân, gia đình và nhóm nhỏ."
            ),
            "rating": round(4.0 + (index % 10) / 10, 1),
            "review_count": 120 + index * 41,
            "adult_price": 120000 + (index % 10) * 55000,
            "child_price": 60000 + (index % 10) * 30000,
            "opening_slots": ["08:00", "10:00", "13:30", "15:30"],
            "capacity_per_slot": 30 + (index % 6) * 15,
            "duration_minutes": 90 + (index % 5) * 30,
            "minimum_age": [0, 3, 6, 8, 0][variant],
            "amenities": ["đỗ xe", "nhà vệ sinh", "quầy đồ uống", "tủ gửi đồ"],
            "cancellation_policy": "Miễn phí trước giờ tham quan 24 giờ.",
        },
    )


HOTEL_BOOKINGS: list[dict] = []
BUS_BOOKINGS: list[dict] = []
RESTAURANT_BOOKINGS: list[dict] = []
FLIGHT_BOOKINGS: list[dict] = []
ATTRACTION_BOOKINGS: list[dict] = []
