"""Safe, dependency-free calculator tools for a calculator agent."""

from __future__ import annotations

import ast
import math
import operator
import statistics
from collections.abc import Callable
from typing import Literal

MAX_EXPRESSION_LENGTH = 500
MAX_AST_NODES = 100
MAX_ABSOLUTE_RESULT = 1e100


def _ok(**payload: object) -> dict:
    return {"success": True, **payload}


def _error(code: str, message: str) -> dict:
    return {"success": False, "error": {"code": code, "message": message}}


def _bounded_number(value: object) -> int | float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise TypeError("Biểu thức chỉ được trả về giá trị số.")
    if not math.isfinite(value) or abs(value) > MAX_ABSOLUTE_RESULT:
        raise ValueError("Kết quả vượt giới hạn an toàn của calculator.")
    return value


def _safe_power(left: float, right: float) -> int | float:
    if abs(right) > 100:
        raise ValueError("Số mũ phải nằm trong khoảng -100 đến 100.")
    return operator.pow(left, right)


def _safe_factorial(value: float) -> int:
    if not isinstance(value, int) or isinstance(value, bool) or not 0 <= value <= 100:
        raise ValueError("factorial chỉ nhận số nguyên từ 0 đến 100.")
    return math.factorial(value)


_BINARY_OPERATORS: dict[type[ast.operator], Callable] = {
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.Div: operator.truediv,
    ast.FloorDiv: operator.floordiv,
    ast.Mod: operator.mod,
    ast.Pow: _safe_power,
}

_UNARY_OPERATORS: dict[type[ast.unaryop], Callable] = {
    ast.UAdd: operator.pos,
    ast.USub: operator.neg,
}

_FUNCTIONS: dict[str, Callable] = {
    "abs": abs,
    "round": round,
    "min": min,
    "max": max,
    "sqrt": math.sqrt,
    "sin": math.sin,
    "cos": math.cos,
    "tan": math.tan,
    "asin": math.asin,
    "acos": math.acos,
    "atan": math.atan,
    "degrees": math.degrees,
    "radians": math.radians,
    "log": math.log,
    "log10": math.log10,
    "exp": math.exp,
    "ceil": math.ceil,
    "floor": math.floor,
    "factorial": _safe_factorial,
}

_CONSTANTS = {"pi": math.pi, "e": math.e, "tau": math.tau}


def _evaluate(node: ast.AST) -> int | float:
    if isinstance(node, ast.Expression):
        return _evaluate(node.body)
    if isinstance(node, ast.Constant):
        return _bounded_number(node.value)
    if isinstance(node, ast.BinOp) and type(node.op) in _BINARY_OPERATORS:
        result = _BINARY_OPERATORS[type(node.op)](
            _evaluate(node.left),
            _evaluate(node.right),
        )
        return _bounded_number(result)
    if isinstance(node, ast.UnaryOp) and type(node.op) in _UNARY_OPERATORS:
        return _bounded_number(_UNARY_OPERATORS[type(node.op)](_evaluate(node.operand)))
    if isinstance(node, ast.Name) and node.id in _CONSTANTS:
        return _CONSTANTS[node.id]
    if (
        isinstance(node, ast.Call)
        and isinstance(node.func, ast.Name)
        and node.func.id in _FUNCTIONS
        and not node.keywords
    ):
        return _bounded_number(
            _FUNCTIONS[node.func.id](*[_evaluate(argument) for argument in node.args]),
        )
    raise ValueError("Biểu thức chứa toán tử, hàm hoặc ký hiệu không được hỗ trợ.")


def _round_result(value: float, precision: int) -> int | float:
    if isinstance(value, int):
        return value
    rounded = round(value, precision)
    return int(rounded) if rounded.is_integer() else rounded


def calculate_expression(expression: str, precision: int = 10) -> dict:
    """Safely evaluate arithmetic and common math functions.

    Supports +, -, *, /, //, %, **, parentheses, constants pi/e/tau and the
    functions abs, round, min, max, sqrt, trigonometry, log, exp and factorial.
    """
    expression = expression.strip()
    if not expression:
        return _error("EMPTY_EXPRESSION", "expression không được để trống.")
    if len(expression) > MAX_EXPRESSION_LENGTH:
        return _error("EXPRESSION_TOO_LONG", "expression dài tối đa 500 ký tự.")
    if not 0 <= precision <= 15:
        return _error("INVALID_PRECISION", "precision phải nằm trong khoảng 0 đến 15.")
    try:
        tree = ast.parse(expression, mode="eval")
        if sum(1 for _ in ast.walk(tree)) > MAX_AST_NODES:
            return _error(
                "EXPRESSION_TOO_COMPLEX", "Biểu thức có quá nhiều thành phần."
            )
        result = _round_result(_evaluate(tree), precision)
    except SyntaxError:
        return _error("INVALID_EXPRESSION", "Biểu thức không đúng cú pháp.")
    except (ArithmeticError, TypeError, ValueError) as exc:
        return _error("CALCULATION_ERROR", str(exc))
    return _ok(expression=expression, result=result)


def calculate_percentage(
    base_value: float,
    percentage: float,
    operation: Literal["of", "increase", "decrease"] = "of",
    precision: int = 10,
) -> dict:
    """Calculate a percentage of a value, or increase/decrease by a percentage."""
    if not math.isfinite(base_value) or not math.isfinite(percentage):
        return _error("INVALID_NUMBER", "Giá trị phải là số hữu hạn.")
    if not 0 <= precision <= 15:
        return _error("INVALID_PRECISION", "precision phải nằm trong khoảng 0 đến 15.")
    factor = percentage / 100
    if operation == "of":
        result = base_value * factor
    elif operation == "increase":
        result = base_value * (1 + factor)
    else:
        result = base_value * (1 - factor)
    try:
        result = _round_result(_bounded_number(result), precision)
    except ValueError as exc:
        return _error("CALCULATION_ERROR", str(exc))
    return _ok(
        base_value=base_value,
        percentage=percentage,
        operation=operation,
        result=result,
    )


def calculate_statistics(values: list[float], precision: int = 10) -> dict:
    """Calculate count, sum, mean, median, min, max, range and population spread."""
    if not values:
        return _error("EMPTY_VALUES", "values phải có ít nhất một số.")
    if len(values) > 10_000:
        return _error("TOO_MANY_VALUES", "values hỗ trợ tối đa 10.000 số.")
    if not 0 <= precision <= 15:
        return _error("INVALID_PRECISION", "precision phải nằm trong khoảng 0 đến 15.")
    if any(not math.isfinite(value) for value in values):
        return _error("INVALID_NUMBER", "Mọi phần tử phải là số hữu hạn.")
    try:
        total = _bounded_number(sum(values))
        result = {
            "count": len(values),
            "sum": _round_result(total, precision),
            "mean": _round_result(statistics.fmean(values), precision),
            "median": _round_result(statistics.median(values), precision),
            "min": min(values),
            "max": max(values),
            "range": _round_result(max(values) - min(values), precision),
            "population_variance": _round_result(
                statistics.pvariance(values), precision
            ),
            "population_standard_deviation": _round_result(
                statistics.pstdev(values),
                precision,
            ),
        }
    except (ArithmeticError, ValueError) as exc:
        return _error("CALCULATION_ERROR", str(exc))
    return _ok(result=result)
