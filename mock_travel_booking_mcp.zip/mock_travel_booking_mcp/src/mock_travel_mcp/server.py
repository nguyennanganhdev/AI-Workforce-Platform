"""Streamable HTTP MCP server protected by a demo API key."""

from __future__ import annotations

import os
import secrets
from pathlib import Path

import uvicorn
from mcp.server.fastmcp import FastMCP
from starlette.requests import Request
from starlette.responses import JSONResponse

from . import __version__
from .calculator import (
    calculate_expression,
    calculate_percentage,
    calculate_statistics,
)
from .service import (
    book_attraction_ticket,
    book_bus_trip,
    book_flight,
    book_hotel,
    book_restaurant,
    cancel_attraction_booking,
    cancel_bus_booking,
    cancel_flight_booking,
    cancel_hotel_booking,
    cancel_restaurant_booking,
    check_attraction_availability,
    check_bus_availability,
    check_flight_availability,
    check_hotel_availability,
    check_restaurant_availability,
    get_attraction_booking,
    get_attraction_details,
    get_bus_booking,
    get_bus_trip_details,
    get_flight_booking,
    get_flight_details,
    get_hotel_booking,
    get_hotel_details,
    get_restaurant_booking,
    get_restaurant_details,
    get_service_catalog,
    list_customer_bookings,
    search_attractions,
    search_bus_trips,
    search_flights,
    search_hotels,
    search_restaurants,
)


def _load_local_env() -> None:
    """Load this demo's .env without adding another dependency."""
    env_file = Path(__file__).resolve().parents[2] / ".env"
    if not env_file.exists():
        return
    for raw_line in env_file.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        os.environ.setdefault(key.strip(), value.strip().strip("'\""))


_load_local_env()

API_KEY = os.getenv("API_KEY", "")
HOST = os.getenv("HOST", "0.0.0.0")
PORT = int(os.getenv("PORT", "8010"))

if not API_KEY:
    raise RuntimeError("API_KEY is required. Copy .env.example to .env and set it.")


mcp = FastMCP(
    name="Mock Travel Booking",
    instructions=(
        "Dùng các tool này để tra cứu và thực hiện booking giả lập cho khách sạn, "
        "chuyến xe và nhà hàng tại Việt Nam. Luôn tra cứu/kiểm tra khả dụng trước "
        "khi đặt; đây là dữ liệu demo trong RAM và không phát sinh thanh toán thật. "
        "MCP cũng hỗ trợ chuyến bay, địa điểm vui chơi và các phép tính an toàn."
    ),
    host=HOST,
    port=PORT,
    streamable_http_path="/mcp",
    stateless_http=True,
    json_response=True,
)

for tool in (
    calculate_expression,
    calculate_percentage,
    calculate_statistics,
    get_service_catalog,
    list_customer_bookings,
    search_hotels,
    get_hotel_details,
    check_hotel_availability,
    book_hotel,
    get_hotel_booking,
    cancel_hotel_booking,
    search_bus_trips,
    get_bus_trip_details,
    check_bus_availability,
    book_bus_trip,
    get_bus_booking,
    cancel_bus_booking,
    search_restaurants,
    get_restaurant_details,
    check_restaurant_availability,
    book_restaurant,
    get_restaurant_booking,
    cancel_restaurant_booking,
    search_flights,
    get_flight_details,
    check_flight_availability,
    book_flight,
    get_flight_booking,
    cancel_flight_booking,
    search_attractions,
    get_attraction_details,
    check_attraction_availability,
    book_attraction_ticket,
    get_attraction_booking,
    cancel_attraction_booking,
):
    mcp.tool()(tool)


@mcp.custom_route("/health", methods=["GET"], include_in_schema=False)
async def health(_: Request) -> JSONResponse:
    tools = await mcp.list_tools()
    return JSONResponse(
        {
            "status": "ok",
            "service": "mock-travel-booking-mcp",
            "version": __version__,
            "transport": "streamable-http",
            "mcp_path": "/mcp",
            "tool_count": len(tools),
            "storage": "in-memory-arrays",
        },
    )


class APIKeyMiddleware:
    """Protect only the MCP transport; the health endpoint stays public."""

    def __init__(self, asgi_app, api_key: str) -> None:
        self.asgi_app = asgi_app
        self.api_key = api_key

    async def __call__(self, scope, receive, send) -> None:
        path = scope.get("path", "")
        if scope.get("type") == "http" and (path == "/mcp" or path.startswith("/mcp/")):
            headers = {
                key.decode("latin-1").lower(): value.decode("latin-1")
                for key, value in scope.get("headers", [])
            }
            supplied = headers.get("x-api-key", "")
            authorization = headers.get("authorization", "")
            if authorization.lower().startswith("bearer "):
                supplied = authorization[7:].strip()
            if not supplied or not secrets.compare_digest(supplied, self.api_key):
                response = JSONResponse(
                    {
                        "error": "unauthorized",
                        "message": (
                            "Gửi API key bằng Authorization: Bearer <key> "
                            "hoặc X-API-Key: <key>."
                        ),
                    },
                    status_code=401,
                    headers={"WWW-Authenticate": "Bearer"},
                )
                await response(scope, receive, send)
                return
        await self.asgi_app(scope, receive, send)


app = APIKeyMiddleware(mcp.streamable_http_app(), API_KEY)


def main() -> None:
    """Run the demo MCP server."""
    uvicorn.run(app, host=HOST, port=PORT, log_level="info")


if __name__ == "__main__":
    main()
