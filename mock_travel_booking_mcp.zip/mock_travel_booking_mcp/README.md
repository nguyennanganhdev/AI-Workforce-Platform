# Mock Travel Booking MCP

MCP giả lập độc lập để demo luồng tra cứu và đặt **khách sạn, chuyến xe, nhà hàng, chuyến bay và địa điểm vui chơi**, đồng thời cung cấp các tool tính toán để tạo calculator agent. Toàn bộ danh mục và booking chỉ là các `list` trong RAM; không có database và không gọi dịch vụ thật.

## Chạy server

Yêu cầu Python 3.11+ và [uv](https://docs.astral.sh/uv/).

```powershell
cd D:\AI-Workforce-Platform\mock_travel_booking_mcp
uv sync
uv run mock-travel-mcp
```

Server mặc định:

- MCP URL: `http://127.0.0.1:8010/mcp`
- Health check: `http://127.0.0.1:8010/health`
- API key: đọc biến `API_KEY` trong file `.env`
- Xác thực hỗ trợ cả `Authorization: Bearer <API_KEY>` và `X-API-Key: <API_KEY>`

Kiểm tra nhanh:

```powershell
Invoke-RestMethod http://127.0.0.1:8010/health
uv run python -m unittest discover -s tests -v
```

## Gắn vào `platform_VP`

Trong màn hình **MCP > Kết nối MCP đối tác**, nhập:

| Trường | Giá trị |
|---|---|
| Mã MCP | `mock_travel` |
| Tên hiển thị | `Mock Travel Booking` |
| MCP URL | `http://127.0.0.1:8010/mcp` |
| API Key | giá trị `API_KEY` trong `.env` |
| Kiểu xác thực | `Authorization: Bearer` |

Nếu `platform_VP` chạy trong Docker còn MCP chạy trên Windows host, dùng URL `http://host.docker.internal:8010/mcp`.

Cấu hình trực tiếp bằng Python:

```python
import os

from agentscope.mcp import HttpMCPConfig, MCPClient

travel_mcp = MCPClient(
    name="mock_travel",
    is_stateful=False,
    mcp_config=HttpMCPConfig(
        url="http://127.0.0.1:8010/mcp",
        headers={"Authorization": f"Bearer {os.environ['TRAVEL_MCP_API_KEY']}"},
    ),
)
```

## Danh sách tool

| Nhóm | Tool |
|---|---|
| Calculator | `calculate_expression`, `calculate_percentage`, `calculate_statistics` |
| Chung | `get_service_catalog`, `list_customer_bookings` |
| Khách sạn | `search_hotels`, `get_hotel_details`, `check_hotel_availability`, `book_hotel`, `get_hotel_booking`, `cancel_hotel_booking` |
| Chuyến xe | `search_bus_trips`, `get_bus_trip_details`, `check_bus_availability`, `book_bus_trip`, `get_bus_booking`, `cancel_bus_booking` |
| Nhà hàng | `search_restaurants`, `get_restaurant_details`, `check_restaurant_availability`, `book_restaurant`, `get_restaurant_booking`, `cancel_restaurant_booking` |
| Chuyến bay | `search_flights`, `get_flight_details`, `check_flight_availability`, `book_flight`, `get_flight_booking`, `cancel_flight_booking` |
| Vui chơi | `search_attractions`, `get_attraction_details`, `check_attraction_availability`, `book_attraction_ticket`, `get_attraction_booking`, `cancel_attraction_booking` |

Các tool tạo booking hỗ trợ `client_reference` để retry không tạo giao dịch trùng. Tool hủy giải phóng tồn kho/chỗ ngồi/sức chứa tương ứng.

Ví dụ calculator:

- `calculate_expression(expression="sqrt(144) + 2 ** 3")`
- `calculate_percentage(base_value=1500000, percentage=10, operation="decrease")`
- `calculate_statistics(values=[8, 9.5, 7, 10])`

`calculate_expression` không dùng `eval`; tool chỉ cho phép toán tử số học, dấu ngoặc, `pi`, `e`, `tau` và các hàm toán học được liệt kê trong mô tả tool.

## Dữ liệu và giới hạn demo

- Dữ liệu mẫu nằm trong `src/mock_travel_mcp/data.py` dưới dạng các array/list.
- Mỗi lĩnh vực có đúng 50 bản ghi catalog: khách sạn, chuyến xe, nhà hàng, chuyến bay và địa điểm vui chơi.
- Booking phát sinh nằm trong năm list `HOTEL_BOOKINGS`, `BUS_BOOKINGS`, `RESTAURANT_BOOKINGS`, `FLIGHT_BOOKINGS`, `ATTRACTION_BOOKINGS`.
- Dữ liệu booking mất khi server restart; đây là hành vi chủ ý cho môi trường demo/test.
- Lịch xe là lịch chạy hằng ngày; tồn chỗ được tính riêng theo ngày người dùng chọn.
- Không có thanh toán thật, gửi email/SMS, đăng nhập khách hàng hoặc kết nối nhà cung cấp.

